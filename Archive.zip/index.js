const Alexa = require('alexa-sdk')
import axios from 'axios'

const handlers = {
    'LaunchRequest': function () {
        this.emit(':ask', 'Welcome to the Dothraki translate skill. What would you like to translate?')
    },

    'Translate': async function () {
        let language = this.event.request.intent.slots.Language.value
        let phrase = this.event.request.intent.slots.PhraseToTranslate.value

        await axios.post('http://api.funtranslations.com/translate/dothraki.json', phrase)
            .on('success', (payload) => {
                const translation = payload.contents.translated
                this.emit(':tell', `${phrase} is ${translation} in ${language}`)
            }).on('error', (payload) => {
                this.emit(':tell', 'Sorry, translation was unsuccessful. Want to try a different phrase?')
            })

    }
}

exports.handler = function (event, context, callback) {
    var alexa = Alexa.handler(event, context)
    alexa.registerHandlers(handlers)
    alexa.execute()
}